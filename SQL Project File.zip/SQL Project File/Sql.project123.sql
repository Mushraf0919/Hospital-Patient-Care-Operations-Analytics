create database Hospital_dbms;
USE Hospital_dbms;

-- creating patients table
create table patients (patient_id varchar(20) primary key,
                       patient_name varchar(100),
                       age int,
                       gender varchar(10),
                       city varchar(50),
                       patient_type varchar(20),
                       preferred_time_slot varchar(20),
                       registration_date DATE
                       );
                       
-- creating doctors table
create table doctors (doctor_id varchar(10) primary key,
					  doctor_name varchar(100),
                      specialty varchar(50),
                      hire_date DATE,
                      rating decimal(3,2),
                      employment_type varchar(20),
                      is_active varchar(3)
                      );
				
-- creating rooms table
create table rooms (room_id varchar(10) primary key,
                    room_type varchar(30),
                    floor int,
                    equipment_type varchar(50),
                    capacity int,
                    last_maintenance_date DATE,
                    is_available varchar(3)
                    );
                    
-- creating appointments table
create table appointments (appointment_id varchar(20) primary key,
                           patient_id varchar(20),
                           appointment_date DATE,
                           doctor_id varchar(10),
                           service_type varchar(30),
                           priority varchar(10),
                           estimated_cost decimal(10,2),
                           booking_channel varchar(20),
                           foreign key (patient_id) references patients(patient_id),
                           foreign key (doctor_id) references doctors(doctor_id)
                           );
                           
-- creating treatments table
create table treatments(treatment_id varchar(20) primary key,
                        appointment_id varchar(20),
                        doctor_id varchar(10),
                        room_id varchar(10),
                        actual_treatment_date DATE,
                        status varchar(20),
                        treatment_attempt int,
                        treatment_duration_min int,
                        waiting_time_min int,
                        treatment_cost decimal(10,2),
                        foreign key (appointment_id) references appointments(appointment_id),
                        foreign key (doctor_id) references doctors(doctor_id),
                        foreign key (room_id) references rooms(room_id)
                        );
                        
SHOW TABLES;
SELECT * FROM patients;
SELECT * FROM doctors;
SELECT * FROM appointments;
SELECT * FROM rooms;
SELECT * FROM treatments;
DESCRIBE patients;
DESCRIBE doctors;
DESCRIBE appointments;
DESCRIBE rooms;
DESCRIBE treatments;  

-- 1.4 Analytical Thinking from the ER Diagram
-- 1. Management wants to identify patients who have booked multiple appointments.
-- Which table and columns are needed?
-- ANS : patients , appointments

-- 2. Operations wants to identify appointments that required more than one treatment attempt. Where is this information found?
-- Ans: treatments

-- 3. Patient Services wants to compare General, Corporate, and Insurance patients based on appointment activity. Which tables must be connected?
-- ANS: patients , appointments

-- 4. Operations wants to compare service types based on treatment duration and waiting time. Which tables are required?
-- ANS: appointments , treatments

-- 5. The team wants to identify which doctors handled treatments and examine their recorded ratings. What information is needed?
-- ANS: doctors , treatments

-- 6. Operations wants to understand whether different room/equipment types are used for different service types. Which tables and columns are required?
-- ANS: appointments , treatments , rooms

-- 7. Management wants to compare treatment performance across cities. What information must be connected?
-- ANS: patients , appointments , treatments

-- 8. Operations wants to investigate whether higher-priority appointments have longer waiting times or different outcomes. What information is needed?
-- ANS: appoinments , treatments

-- 9. Management wants to understand whether treatment outcomes differ across service types. What tables and fields should be combined?
-- ANS: appointment , treatments

-- 10. The Patient Services team wants to connect each patient to their appointments and treatment outcomes. What relationships are required?
-- ANS: patients , appointments , treatments

-- Sprint 2: Database Setup
SHOW TABLES;
-- Sprint 3: Basic Analysis / Data Exploration
-- 1. What is the total number of patients?
SELECT COUNT(*) FROM patients;

-- 2. What is the total number of appointments?
SELECT COUNT(*) FROM appointments;

-- 3. What is the total number of treatment records?
SELECT COUNT(*) FROM treatments;

-- 4. What are the different medical service types?
SELECT DISTINCT service_type FROM appointments;

-- 5. How many doctors are currently active?
SELECT COUNT(*) AS active_doctor FROM doctors WHERE is_active = 'Yes';

-- 6. What are the different room types?
SELECT DISTINCT room_type as Different_room_types FROM rooms;

-- 7. What is the total estimated appointment value?
SELECT SUM(estimated_cost) as total_estimated_value FROM appointments;

-- 8. What is the average treatment duration?
SELECT AVG(treatment_duration_min) as average_treatment_duration from treatments;

-- Sprint 4: Objective-Based Analysis
-- 4.1 Understand Patient and Appointment Demand
-- Compare appointment volume across cities.
select p.city , count(a.appointment_id) as total_appointments
from patients p join appointments a on p.patient_id = a.patient_id 
group by p.city order by total_appointments desc;

-- Compare appointments across service types and priorities.
select service_type , priority , count(*) as total_appointments
from appointments
group by service_type , priority  order by service_type ,  total_appointments desc;

-- Examine appointment volume over time.
select date_format(appointment_date, '%Y-%m') as appointment_month, count(*) as total_appointments
from appointments
group by date_format(appointment_date, '%Y-%m')
order by appointment_month;

-- Compare estimated appointment value across patient types.
select
    p.patient_type,
    count(a.appointment_id) as total_appointments,
    sum(a.estimated_cost) as total_estimated_value,\
    avg(a.estimated_cost) as average_estimated_cost
from patients p
join appointments a
    on p.patient_id = a.patient_id
group by p.patient_type
order by total_estimated_value desc;

-- Examine booking channels and their contribution to demand.
select
    booking_channel,
    count(*) as total_appointments,
	count(*) * 100 / (select count(*) from appointments) as demand_percentage
from appointments
group by  booking_channel
order by total_appointments desc;

-- 4.2 Understand Patient Appointment Behaviour
-- Compare patients by number of appointments.
select
    p.patient_id,
    p.patient_name,
    count(a.appointment_id) as total_appointments
from patients p
join appointments a
    on p.patient_id = a.patient_id
group by p.patient_id, p.patient_name
order by total_appointments desc;

-- Identify patients with higher cumulative estimated appointment value.
select
    p.patient_id,
    p.patient_name,
    sum(a.estimated_cost) as total_estimated_value
from patients p
join appointments a
    on p.patient_id = a.patient_id
group by p.patient_id, p.patient_name
order by total_estimated_value desc;

-- Compare patient activity across cities.
select
    p.city,
    count(distinct p.patient_id) as total_patients,
    count(a.appointment_id) as total_appointments
from patients p
left join appointments a
    on p.patient_id = a.patient_id
group by p.city
order by total_appointments desc;

-- Compare General, Corporate, and Insurance patients.
select
    p.patient_type,
    count(distinct p.patient_id) as total_patients,
    count(a.appointment_id) as total_appointments,
    sum(a.estimated_cost) as total_estimated_value,
    avg(a.estimated_cost) as average_estimated_cost
from patients p
left join appointments a
    on p.patient_id = a.patient_id
group by p.patient_type
order by total_appointments desc;

-- Examine patient booking patterns over time.
select
    p.patient_id,
    p.patient_name,
    date_format(a.appointment_date, '%y-%m') as appointment_month,
    count(a.appointment_id) as total_appointments
from patients p
join appointments a
    on p.patient_id = a.patient_id
group by
    p.patient_id,
    p.patient_name,
    date_format(a.appointment_date, '%y-%m')
order by appointment_month, total_appointments desc;

-- 4.3 Evaluate Treatment Performance
-- Compare treatment outcomes across cities.
select
    p.city,
    t.status,
    count(*) as total_treatments
from treatments t
join appointments a
    on t.appointment_id = a.appointment_id
join patients p
    on a.patient_id = p.patient_id
group by p.city, t.status
order by p.city, total_treatments desc;

-- Examine treatment duration and waiting time.

SELECT AVG(treatment_duration_min) AS avg_duration, 
       AVG(waiting_time_min) AS avg_wait
FROM treatments;

-- Compare Completed, Cancelled, No-Show, Rescheduled, and In Progress outcomes.

SELECT 
    status, COUNT(*) AS total, SUM(treatment_cost) AS total_cost
FROM
    treatments
GROUP BY status;

-- Identify areas with higher treatment activity or poorer outcomes.

SELECT r.room_type, t.status, COUNT(*) AS total
FROM treatments t
JOIN rooms r ON t.room_id = r.room_id
GROUP BY r.room_type, t.status
ORDER BY total DESC;

-- Compare treatment performance over time.

SELECT DATE_FORMAT(actual_treatment_date, '%Y-%m') AS month,
       COUNT(*) AS volume,
       AVG(waiting_time_min) AS avg_wait
FROM treatments
GROUP BY month
ORDER BY month;

-- 4.4 Understand Doctor and Room Performance
-- Compare the number of treatments handled by doctors.

SELECT doctor_id, COUNT(*) AS total_treatments
FROM treatments
GROUP BY doctor_id
ORDER BY total_treatments DESC;

-- Compare doctor performance across treatment outcomes.

SELECT doctor_id,
       SUM(status = 'Completed') AS completed,
       SUM(status = 'Cancelled') AS cancelled,
       SUM(status = 'No-Show') AS no_show
FROM treatments
GROUP BY doctor_id;

-- Examine treatment duration across doctors.

SELECT doctor_id,
       ROUND(AVG(treatment_duration_min), 1) AS avg_duration,
       MAX(treatment_duration_min) AS max_duration
FROM treatments
GROUP BY doctor_id
ORDER BY avg_duration DESC;

-- Compare room usage across room types and equipment types.

SELECT r.room_type, r.equipment_type, 
       COUNT(t.treatment_id) AS total_usage
FROM treatments t
JOIN rooms r ON t.room_id = r.room_id
GROUP BY r.room_type, r.equipment_type
ORDER BY total_usage DESC;

-- Evaluate treatment performance across rooms.

SELECT room_id, COUNT(*) AS total_treatments,
       ROUND(AVG(status = 'Completed') * 100, 1) AS success_rate_pct,
       ROUND(AVG(waiting_time_min), 1) AS avg_wait
FROM treatments
GROUP BY room_id
ORDER BY success_rate_pct DESC;


-- 4.5 Identify Treatment and Appointment Problems
-- Identify appointments requiring multiple treatment attempts.

SELECT appointment_id, MAX(treatment_attempt) AS total_attempts
FROM treatments
GROUP BY appointment_id
HAVING total_attempts > 1
ORDER BY total_attempts DESC;

-- Find common problem statuses and patterns.

SELECT status, COUNT(*) AS case_count,
       ROUND(AVG(treatment_attempt), 1) AS avg_attempts,
       ROUND(AVG(waiting_time_min), 1) AS avg_wait
FROM treatments
WHERE status IN ('Cancelled', 'No-Show', 'Rescheduled')
GROUP BY status ORDER BY case_count DESC;

-- Compare waiting time for appointments with multiple attempts.

SELECT (treatment_attempt > 1) AS has_multiple_attempts,
       COUNT(DISTINCT appointment_id) AS total_appointments,
       ROUND(AVG(waiting_time_min), 1) AS avg_wait_time
FROM treatments
GROUP BY has_multiple_attempts;

-- Identify cities or service types with more cancellations, no-shows, or rescheduling.

SELECT p.city, a.service_type,
       SUM(t.status IN ('Cancelled', 'No-Show', 'Rescheduled')) AS total_problems
FROM treatments t
JOIN appointments a ON t.appointment_id = a.appointment_id
JOIN patients p ON a.patient_id = p.patient_id
GROUP BY p.city, a.service_type
ORDER BY total_problems DESC;


-- Investigate whether priority level is associated with waiting time or treatment outcomes.

SELECT a.priority,
       ROUND(AVG(t.waiting_time_min), 1) AS avg_wait,
       ROUND(AVG(t.status = 'Completed') * 100, 1) AS completion_pct
FROM treatments t
JOIN appointments a ON t.appointment_id = a.appointment_id
GROUP BY a.priority ORDER BY avg_wait ASC;

-- Final conclusions and practical recommendations: 

-- Consultation is the dominant service by appointment and treatment volume. 
-- Ensure sufficient consultation capacity and review its high absolute number of cancellations, 
-- no-shows and reschedules.

-- Kochi has the largest appointment and treatment volumes. 
-- Review staffing and room capacity there; compare outcome percentages before concluding it performs worse.

-- July and April are the busiest appointment months in 2025. 
-- Plan staffing and room availability around demand peaks.

-- The App is the leading booking channel. 
-- Continue monitoring its demand and conversion to completed visits.

-- Average waits are close across priority categories. 
-- Urgent appointments have a slightly higher average wait; review urgent-case workflows, 
-- but do not infer causation from this descriptive analysis.

-- The 500 second-attempt appointments should be examined separately 
-- because repeat attempts increase treatment-row counts and may affect averages.

-- Use outcome rates, sample sizes and case mix together when comparing cities, services, doctors and rooms. 
-- Counts alone can be misleading.